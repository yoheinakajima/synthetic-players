# arXiv submission checklist

## Upload files

- Source archive: [`docs/paper/synthetic-players-arxiv-source.zip`](docs/paper/synthetic-players-arxiv-source.zip)
- Reference PDF: [`docs/paper/synthetic-players.pdf`](docs/paper/synthetic-players.pdf)
- Exact TeX source: [`arxiv/main.tex`](arxiv/main.tex)
- PDF checksum: [`docs/paper/synthetic-players.sha256`](docs/paper/synthetic-players.sha256)
- Timestamp proof: `docs/paper/synthetic-players.sha256.otsR

The source archive contains only `main.tex` and five PDF figures and has been compiled twice in a fresh directory.

## Suggested arXiv fields

**Title**  
Passing Coarse Marginal Checks Can Be Cheap: Persona Mixtures and Imprecise Treatment-Response Estimates in an LLM Persona Panel

**Author**  
Yohei Nakajima

**Suggested primary category**  
`cs.AI`

**Suggested cross-list**  
`cs.HC`

**Comments**  
18 pages, 5 figures. Code, data, registrations, review record, and zero-call replay capsule: https://github.com/yoheinakajima/synthetic-players

## Operator sequence

1. Upload `synthetic-players-arxiv-source.zip`, not the PDF alone.
2. Confirm that arXiv selects `main.tex` and compiles with PDFLaTeX.
3. Compare arXiv's generated PDF with `synthetic-players.pdf`, especially page 1, all five figures, tables, references, and Appendix A.4.
4. Confirm that the abstract ends with “do not establish human substitutability.”
5. Select the submission license in the arXiv interface.
6. Submit and record the assigned identifier.
7. Update `CITATION.cff`, the project site, and README with the stable arXiv URL and DOI.

## Scientific freeze

The experiment is closed. Typographic, metadata, or clearly labeled correction updates are permitted; historical registrations, event data, and mechanical verdicts must not be rewritten. New empirical claims require a new registration and release lineage.
